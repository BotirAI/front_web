import React from 'react'
import lg_logo from '../images/lg_logo.png'

export default function Footer() {
  return (
    <div className='footer'>
        {/* <img src={lg_logo} alt="logo" /> */}
        <p>Cyberpark tomonidan tayyorlangan.</p>
    </div>
  )
}
