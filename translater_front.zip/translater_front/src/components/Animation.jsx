import "./Animation.css"

export const Animation = () => {
    return (
        <>
            <div>
                <ul className="boxArea">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
        </>
    );
};